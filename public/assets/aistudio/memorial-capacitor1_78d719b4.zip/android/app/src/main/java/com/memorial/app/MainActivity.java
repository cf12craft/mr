package com.memorial.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
